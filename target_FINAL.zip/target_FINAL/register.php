<?php
session_start();
/*include 'model/function_BD.php';
include 'model/functions.php';
if (isset($_SESSION['pseudo'])) {
    header('Location:index.php');
    exit;
}
gotInfos();
if (isset($_REQUEST["mailInscri"]) && isset($_REQUEST["passwordInscri"]) && isset($_REQUEST["pseudoInscri"])) {
    $mailCheck = checkIfNotAlreadyInMail($_REQUEST["mailInscri"]);
    $pseudoCheck = checkIfNotAlreadyInPseudo($_REQUEST["pseudoInscri"]);
    if (isset($mailCheck[0])) {
        echo 'Mail déjà utiliser';
    } else {
        if (isset($pseudoCheck[0])) {
            echo 'Pseudo déjà utiliser';
        } else {
            subscribe($_REQUEST["mailInscri"], sha1($_REQUEST["passwordInscri"]), $_REQUEST["pseudoInscri"], $_REQUEST["nom"], $_REQUEST["prenom"], $_REQUEST["description"]);
            $_SESSION['pseudo'] = $_REQUEST["pseudoInscri"];
            $_SESSION['mail'] = $_REQUEST["mailInscri"];
            header('Location:index.php');
            exit;
        }
    }
}*/


require './model/function_BD.php';
require './model/functions.php';

$modifier = false;
$idUser = isset($_GET['idUser']) ? $_GET['idUser'] : null;
$users = getUsersById($idUser);
$prenom = "";
$nom = "";
$pseudo = "";
$email = "";
$motDePasse = "";
$description = "";
$age = "";

$genre = "";
$langue = 0;
$taille = 0;
$poids = 0;
$emploi = "";
$idLieu = 0;

if (filter_has_var(INPUT_POST, "submit")) {
    $prenom = trim(filter_input(INPUT_POST, "prenom", FILTER_SANITIZE_STRING));
    $nom = trim(filter_input(INPUT_POST, "nom", FILTER_SANITIZE_STRING));
    $pseudo = trim(filter_input(INPUT_POST, "pseudoInscri", FILTER_SANITIZE_STRING));
    $email = trim(filter_input(INPUT_POST, "mailInscri", FILTER_SANITIZE_EMAIL));
    $motDePasse = trim(filter_input(INPUT_POST, "passwordInscri", FILTER_SANITIZE_STRING));
    $description = trim(filter_input(INPUT_POST, "description", FILTER_SANITIZE_STRING));
    $age = trim(filter_input(INPUT_POST, "age", FILTER_SANITIZE_STRING));
    
    $genre = trim(filter_input(INPUT_POST, "genre", FILTER_SANITIZE_STRING));
    $langue = trim(filter_input(INPUT_POST, "langue", FILTER_VALIDATE_INT));
    $taille = trim(filter_input(INPUT_POST, "taille", FILTER_VALIDATE_INT));
    $poids = trim(filter_input(INPUT_POST, "poids", FILTER_VALIDATE_INT));
    $emploi = trim(filter_input(INPUT_POST, "jobs", FILTER_SANITIZE_STRING));
    $idLieu = trim(filter_input(INPUT_POST, "ville", FILTER_VALIDATE_INT));

    if(empty($email)){
        $erreurs['email'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['email']);
    }
    if(empty($nom)){
        $erreurs['nom'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['nom']);
    }
    else if(empty($prenom)){
        $erreurs['prenom'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['prenom']);
    }
    else if(empty($pseudo)){
        $erreurs['pseudo'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['pseudo']);
    }
    else if(empty($motDePasse)){
        $erreurs['password'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['password']);
    }
    
    /*if (strcmp($pwd, $pwdConfirm) !== 0) {
        $erreurs['password'] = "Les mots de passe ne correspondent pas !";
        SetFlashMessage($erreurs['password']);
    }*/
    
    if (empty($erreurs)) {
        subscribe($pseudo, $email, $motDePasse, $nom, $prenom, $description,$age,1);
        createCaracteristique($genre, $langue, $taille, $poids, $emploi, $idLieu,returnLastId());
        SetFlashMessage("Votre compte a été crée !");
        header("location:index.php");
        exit;
    }
}

require_once 'views/userform.php';