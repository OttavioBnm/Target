<?php
/*
 * Fonction de remplissage, toutes les infos dispo dans le $_Session
 */
function gotInfos() {
    if (isset($_SESSION['mail'])) {
        $infoUser = checkIfNotAlreadyInMail($_SESSION['mail']);
        foreach ($infoUser as $value) {
            $_SESSION['idUser'] = $value['idUtilisateur'];
            $_SESSION['nom'] = $value['nom'];
            $_SESSION['pseudo'] = $value['nomCompte'];
            $_SESSION['prenom'] = $value['prenom'];
            $_SESSION['mail'] = $value['eMail'];
            $_SESSION['description'] = $value['description'];
            $_SESSION['dateDeNaissance'] = $value['dateNaissance'];
            $caracteristique = getCaracteristiquesById($value['idUtilisateur']);
            foreach($caracteristique as $info){
            $_SESSION['taille']  = $info['taille'];
            $_SESSION['poids']   = $info['poids'];
            $_SESSION['genre']   = $info['genre'];
            $_SESSION['emplois'] = $info['emplois'];
            $_SESSION['idLieu']  = $info['idLieu'];
            $_SESSION['langue']  = $info['langue'];}
        }  
    }
}
/*
 * Destrcuteur de session avec redirection
 */
function deco(){
    $_SESSION = array();
session_destroy();
unset($_SESSION);
header('Location:index.php');
}
/*fonction pour pas retaper constament la redirection
 */
function backHome(){
    header('Location:index.php');
}

/*
 * Création de la listbox qui permet de déterminer la taille de l'utilisateur
 */
function CreateListBoxHeight(){
    echo '
        <div class="form-group">
            <label for="taille">Taille :</label>
            <select class="form-control" id="taille" name="taille">';
    for($i = 140; $i <= 210; $i++){
            echo "<option value=\"$i\">$i cm</option>";
    }
    echo '</select>
        </div>';
}

/*
 * Création de la listbox qui permet de déterminer le poids de l'utilisateur
 */
function CreateListBoxWeigth(){
    echo '
        <div class="form-group">
            <label for="poids">Poids :</label>
            <select class="form-control" id="poids" name="poids">';
    for($i = 45; $i <= 120; $i++){
        echo "<option value=\"$i\">$i kg</option>";
    }
    echo '
        </select>
        </div>';
}

/*
 * Création de la listbox qui permet de déterminer le genre de l'utilisateur
 */
function CreateListBoxGender(){
    echo '
        <div class="form-group">
            <label for="genre">Genre :</label>
            <select class="form-control" id="genre" name="genre">
                <option value="Homme">Homme</option>
                <option value="Femme">Femme</option>
                <option value="Autre">Autre</option>
            </select>
        </div>';
}

/*
 * Création de la listbox qui permet de déterminer l'âge de l'utilisateur
 */
function CreateListBoxAge(){
    echo '
        <div class="form-group">
            <label for="age">Âge :</label>
            <select class="form-control" id="age" name="age">';
    for($i = 18; $i <= 80; $i++){
        echo "<option value=\"$i\">$i ans</option>";
    }
    echo'</select>
        </div>';
}

/*
 * Création de la listbox qui permet de déterminer le lieu de l'utilisateur
 */
function CreateListBoxCities(){
    $ya = getCities();
    echo '<div class="form-group">
            <label for="ville">Villes :</label>
            <select class="form-control" id="ville" name="ville">';
    foreach ($ya as $villes){
        echo "<option value=" . $villes['idLieu'] .">" . $villes['lieu'] ."</option>";
    }
    echo'</select>
        </div>';
}

/*
 * Création de la listbox qui permet de déterminer la langue de l'utilisateur
 */
function CreateListBoxLanguages(){
    $ya = getLanguages();
    echo '<div class="form-group">
            <label for="langue">Langues :</label>
            <select class="form-control" id="langue" name="langue">';
    foreach ($ya as $languages){
        echo "<option value=" . $languages['idLangue'] .">" . $languages['langue'] ."</option>";
    }
    echo'</select>
        </div>';
}

function CreateListBoxJob(){
    echo   '<div class="form-group">
                <label for="jobs">Statut professionnel :</label>
                    <select class="form-control" id="jobs" name="jobs">
                        <option value="Étudiant">Étudiant</option>
                        <option value="Employé">Employé</option>
                        <option value="Employeur">Employeur</option>
                        <option value="Chômeur">Chômeur</option>
                    </select>
                </label>
            </div>';
}

function CreateTextBoxJob(){
    echo    "<div class=\"form-group\">
                <label for=\"statutPro\">Statut professionel</label>
                <input name=\"statutPro\" type=\"email\" class=\"form-control\" id=\"statutPro\" aria-describedby=\"emailHelp\" placeholder=\"Entrez votre statut professionel\">
            </div>";
}
/*Affichage de la navBar en fonction de la connexion*/
function ContextNavBar(){
    if(isset($_SESSION["pseudo"])){
              echo '<ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Accueil <span class="sr-only"></span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./profil.php?'.$_SESSION["pseudo"].'">Mon profil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="model/deconnexion.php">Déconnexion</a>
                    </li>
                    </ul>
                    <form class="form-inline my-2 my-lg-0" action="users.php" method="post">
                        <input class="form-control mr-sm-2" type="text" placeholder="Rechercher un profil" name="searcher">
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Rechercher</button>
                    </form>';
          }
          else{
              echo '<ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Accueil <span class="sr-only"></span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register.php">Inscription</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="login.php">Connexion</a>
                        </li>
                        </ul>';
          }
}
/* verifie si l'user est déjà en attente de reponse à un like*/
function DemandeAlreadyDone($idAsking,$idReceiver){
    $reponse=getDemandesByIdAsking($idAsking);
    foreach ($reponse as $person) {
        if ($idReceiver==$person["idUserReciver"]) {
            return true;
        }
        else{
            return false;
        }
    }
}

function createPagination($nbPage,$idUserSearch){
    echo'<div class="btn-group" role="group" aria-label="Basic example">';
    for ($index = 0; $index < $nbPage; $index++) {
        echo '<button type="button" class="btn btn-secondary"><a href="users.php?idUserSearch='.$idUserSearch.'&limit='.$index.'">'.$index.'</a></button>';
    }
    echo'</div>';
}

function MatchAlreadyDone($idAsking,$idReceiver){
    $reponse= getMatchsByIdAsking($idAsking, $idReceiver);
    foreach ($reponse as $person) {
        if ($idReceiver==$person["matchUserOne"] || $idReceiver==$person["matchUserTwo"] ) {
            return true;
        }
        else{
            return false;
        }
    }
}
function SetFlashMessage($message){
    $_SESSION['message'] = $message;
}

function GetFlashMessage(){
    $message = isset($_SESSION['message']) ? $_SESSION['message'] : "";
    $_SESSION['message'] = "";
    return $message;
}