<?php
DEFINE("DB_HOST","127.0.0.1");
DEFINE("DB_NAME","target_final");
DEFINE("DB_USER","root");
DEFINE("DB_PASS","");
/*
 * Connection à la base de données
 */
function getConnexion(){
    static $dbb=null;
    if($dbb==null){
        try{
        $connectionString="mysql:host=".DB_HOST.";dbname=".DB_NAME."";
        $dbb=new PDO($connectionString,DB_USER,DB_PASS, array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
        $dbb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        }
        catch(PDOException $e){
            die('Erreur : '. $e->getMessage() );
        }
    }
    return $dbb;
}
/*
 * Requête d'inscription
 */
function subscribe($pseudo,$mail,$pass,$nom,$prenom,$description,$dateNaissance,$idCaracteristique){     
    $connexion=getConnexion();
    $request=$connexion->prepare("INSERT INTO `tutilisateur` (`nomCompte`, `eMail`, `mdp`, `nom`, `prenom`, `description`, dateNaissance, `idCaracteristique`) VALUES (:login,:mail,:pass,:nom,:prenom,:description,:dateNaissance,:idCaracteristique);");
    $request->bindParam(':mail',$mail,PDO::PARAM_STR);
    $request->bindParam(':pass',$pass,PDO::PARAM_STR);
    $request->bindParam(':login',$pseudo,PDO::PARAM_STR);
    $request->bindParam(':nom',$nom,PDO::PARAM_STR);
    $request->bindParam(':prenom',$prenom,PDO::PARAM_STR);
    $request->bindParam(':description',$description,PDO::PARAM_STR);
    $request->bindParam(':dateNaissance',$dateNaissance);
    $request->bindParam(':idCaracteristique',$idCaracteristique,PDO::PARAM_STR);
    $request->execute(); 
}

function CreateXUser($nb){
    for ($index = 0; $index < $nb; $index++) {
        subscribe($index, $index.'@'.$index.".com", $index, "test", $index, $index, 18, 2);
    }
}

function updateUser($pseudo,$mail,$pass,$nom,$prenom,$description,$dateNaissance,$idUtilisateur){
    $connexion=getConnexion();
    $request=$connexion->prepare("UPDATE `tutilisateur` SET `nomCompte`=:pseudo,`eMail`=:mail,`mdp`=:pass,`nom`=:nom,`prenom`=:prenom,`description`=:description,`dateNaissance`=:dateNaissance WHERE `idUtilisateur`=:idUtilisateur");
    $request->bindParam(':mail',$mail,PDO::PARAM_STR);
    $request->bindParam(':pass',$pass,PDO::PARAM_STR);
    $request->bindParam(':pseudo',$pseudo,PDO::PARAM_STR);
    $request->bindParam(':nom',$nom,PDO::PARAM_STR);
    $request->bindParam(':prenom',$prenom,PDO::PARAM_STR);
    $request->bindParam(':description',$description,PDO::PARAM_STR);
    $request->bindParam(':dateNaissance',$dateNaissance);
    $request->bindParam(':idUtilisateur',$idUtilisateur,PDO::PARAM_STR);
    $request->execute(); 
}

function updateCaracteristique($genre,$langue,$taille,$poids,$emploi,$idLieu,$idUtilisateur){
    $connexion=getConnexion();
    $request=$connexion->prepare("UPDATE `tcaracteristique` SET `genre`=:genre,`langue`=:langue,`taille`=:taille,`poids`=:poids,`emplois`=:emploi,`idLieu`=:idLieu WHERE `idUtilisateur`=:idUtilisateur ");
    $request->bindParam(':genre',$genre,PDO::PARAM_STR);
    $request->bindParam(':langue',$langue,PDO::PARAM_INT);
    $request->bindParam(':taille',$taille,PDO::PARAM_INT);
    $request->bindParam(':poids',$poids,PDO::PARAM_INT);
    $request->bindParam(':emploi',$emploi,PDO::PARAM_STR);
    $request->bindParam(':idLieu',$idLieu,PDO::PARAM_INT);
    $request->bindParam(':idUtilisateur',$idUtilisateur,PDO::PARAM_INT);
    $request->execute();
}
/*
 * Vérification que le mail n'est pas déjà présent
 */
function checkIfNotAlreadyInMail($mail){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `tutilisateur` WHERE `email`=:mail");
    $request->bindParam(':mail',$mail,PDO::PARAM_STR);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
/*
 * Vérification que le pseudo n'est pas déjà présent
 */
function checkIfNotAlreadyInPseudo($pseudo){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `tutilisateur` WHERE `nomCompte`=:pseudo");
    $request->bindParam(':pseudo',$pseudo,PDO::PARAM_STR);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
/*
 * Recupère tout les tutilisateurs
 */
function getUsers(){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `tutilisateur`");
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}

function getUserIdByPseudo($pseudo){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT idUtilisateur FROM `tutilisateur` WHERE `nomCompte`=:pseudo");
    $request->bindParam(':pseudo',$pseudo,PDO::PARAM_STR);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}

function getUsersById($id){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `tutilisateur` WHERE idUtilisateur=:id");
    $request->bindParam(':id',$id,PDO::PARAM_INT);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}

/*
 * Requete de connection 
 */
function checkIn($email,$password){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `tutilisateur` WHERE `eMail`=:email AND `mdp`=:password");
    $request->bindParam(':email',$email,PDO::PARAM_STR);
    $request->bindParam(':password',$password,PDO::PARAM_STR);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
/*Requete de modification (prend la colone de la table pour modifier les paramètre voulue) /!\ PAS DE PROTECTION EN BIND QUE DU CODE PHP NON ACCESSIBLE PAR L'USER
 */
function modif($id,$nomColone,$changement){
    $connexion=getConnexion();
    $request=$connexion->prepare("UPDATE tutilisateur SET ".$nomColone."= :changement WHERE `tutilisateur`.`idUser` = :id;");
    $request->bindParam(':changement',$changement,PDO::PARAM_STR);
    $request->bindParam(':id',$id,PDO::PARAM_INT);
    $request->execute();
}
/*Suppression du profil
 */
function suppProfil($id){
    $connexion=getConnexion();
    $request=$connexion->prepare("DELETE FROM tutilisateur WHERE `idUser`=:id;");
    $request->bindParam(':id',$id,PDO::PARAM_INT);
    $request->execute();
}

function getCities(){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `tlieu`");
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
function getLanguagesById($id){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `langue` WHERE idLangue=:id");
    $request->bindParam(':id',$id,PDO::PARAM_INT);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}

function getLanguages(){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `langue`");
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}

function getCaracteristiquesById($id){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `tcaracteristique` WHERE idUtilisateur=:id");
    $request->bindParam(':id',$id,PDO::PARAM_INT);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
function SerachByNam($id,$name){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `tutilisateur` WHERE `idUtilisateur` != :idUser AND `nom`=:nameSearch OR `idUtilisateur` !=:idUser AND `prenom`=:nameSearch");
    $request->bindParam(':idUser',$id,PDO::PARAM_INT);
    $request->bindParam(':nameSearch',$name,PDO::PARAM_INT);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}

function SerachByNameLimit($id,$name,$limit){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `tutilisateur` WHERE `idUtilisateur` != :idUser AND `nom`=:nameSearch OR `idUtilisateur` !=:idUser AND `prenom`=:nameSearch LIMIT :limit,4");
    $request->bindParam(':limit', $limit,PDO::PARAM_INT);
    $request->bindParam(':idUser',$id,PDO::PARAM_INT);
    $request->bindParam(':nameSearch',$name,PDO::PARAM_INT);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}

function createCaracteristique($genre,$langue,$taille,$poids,$emploi,$idLieu,$idUtilisateur){
    $connexion=getConnexion();
    $request=$connexion->prepare("INSERT INTO `tcaracteristique` (`genre`, `langue`, `taille`, `poids`, `emplois`, `idLieu`, `idUtilisateur`) VALUES (:genre,:langue,:taille,:poids,:emploi,:idLieu,:idUtilisateur);");
    $request->bindParam(':genre',$genre,PDO::PARAM_STR);
    $request->bindParam(':langue',$langue,PDO::PARAM_INT);
    $request->bindParam(':taille',$taille,PDO::PARAM_INT);
    $request->bindParam(':poids',$poids,PDO::PARAM_INT);
    $request->bindParam(':emploi',$emploi,PDO::PARAM_STR);
    $request->bindParam(':idLieu',$idLieu,PDO::PARAM_INT);
    $request->bindParam(':idUtilisateur',$idUtilisateur,PDO::PARAM_INT);
    $request->execute();
}
function getLocation($id){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT lieu FROM `tlieu` WHERE idLieu=:id");
    $request->bindParam(':id',$id,PDO::PARAM_INT);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
function returnLastId(){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT LAST_INSERT_ID(idUtilisateur) FROM `tutilisateur`");
    return $connexion->lastInsertId();
}
/*DEMANDES*/
function getDemandes(){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `demandes`");
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
function getDemandesByIdReceiver($id){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `demandes` WHERE `idUserReciver`=:id");
    $request->bindParam(':id',$id,PDO::PARAM_STR);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
function getDemandesByIdAsking($id){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `demandes` WHERE `idUserAsking`=:id");
    $request->bindParam(':id',$id,PDO::PARAM_STR);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
function addDemandes($idAsking,$idReceiver){
    $connexion=getConnexion();
    $request=$connexion->prepare("INSERT INTO `demandes`(`idDemandes`, `idUserReciver`, `idUserAsking`,`matching`) VALUES (NULL,:idReceiver,:idAsking,FALSE);");
    $request->bindParam(':idAsking',$idAsking,PDO::PARAM_STR);
    $request->bindParam(':idReceiver',$idReceiver,PDO::PARAM_STR);
    $request->execute();
}
function DelDemandes($idAsking,$idReceiver){
    $connexion=getConnexion();
    $request=$connexion->prepare("DELETE FROM `demandes` WHERE `idUserAsking` = :idAsking AND  `idUserReciver`=:idReceiver;");
    $request->bindParam(':idAsking',$idAsking,PDO::PARAM_STR);
    $request->bindParam(':idReceiver',$idReceiver,PDO::PARAM_STR);
    $request->execute();
}
/*DEMANDES*/
function getmatchs(){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `match`");
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
function getmatchsById($id){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `match` WHERE `matchUserOne`=:id OR `matchUserTwo`=:id");
    $request->bindParam(':id',$id,PDO::PARAM_STR);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
function getMatchsByIdAsking($id){
    $connexion=getConnexion();
    $request=$connexion->prepare("SELECT * FROM `match` WHERE `matchUserOne`=:id");
    $request->bindParam(':id',$id,PDO::PARAM_INT);
    $request->execute();
    $resulat=$request->fetchAll(PDO::FETCH_ASSOC);
    return $resulat;
}
function addMatchs($idAsking,$idReceiver){
    $connexion=getConnexion();
    $request=$connexion->prepare("INSERT INTO `match` (`idMatch`, `matchUserOne`, `matchUserTwo`) VALUES (NULL,:idOne,:idTwo);");
    $request->bindParam(':idOne',$idAsking,PDO::PARAM_STR);
    $request->bindParam(':idTwo',$idReceiver,PDO::PARAM_STR);
    $request->execute();
}