<?php
session_start();
include 'model/function_BD.php';
include 'model/functions.php';
if (isset($_SESSION['pseudo'])) {
    gotInfos();
}
else{
    header('Location:index.php');
}
if(isset($_REQUEST["searcher"])){
   $nbUser=SerachByNam($_SESSION['idUser'],$_REQUEST["searcher"]);
   $nbPage = count($nbUser)/4;
   $namesOfResearch= SerachByNameLimit($_SESSION['idUser'],$_REQUEST["searcher"],1);
}
else if(isset($_GET['idUserSearch'])){
   $nbUser=SerachByNam($_SESSION['idUser'],$_GET['idUserSearch']);
   $nbPage = count($nbUser)/4;
   $namesOfResearch= SerachByNameLimit($_SESSION['idUser'],$_GET["idUserSearch"],1);
}
else{
    header("location:index.php");
    exit();
}
if(isset($_GET["addId"])){
    addDemandes($_SESSION['idUser'], $_GET["addId"]);
    echo 'Id User:'.$_SESSION['idUser'].'<br>';
    echo 'Id User:'.$_GET["addId"].'<br>';
    header("location:profil.php");
    exit;
}
if(isset($_GET["search"])){
    $nameToSearch=$_GET["search"];
    $namesOfResearch= SerachByNam($_SESSION['idUser'],$nameToSearch);
    foreach ($namesOfReserch as $person) {
        var_dump($person);
    }
}
?>
<!DOCTYPE html>
<html lang="fr">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Accueil</title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap-4.0.0-dist/css/bootstrap.min.css" rel="stylesheet">
	
    <!-- CSS de la page !-->
    <link href="css/index.css" rel="stylesheet">
    
    <!-- CSS des icônes !-->
    <link href="../font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet">

  </head>

  <body>
	<div class="fond">
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-toggleable-md fixed-top navbar-inverse">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand" href="index.php">Target</a>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <?php 
        ContextNavBar();
        ?>
      </div>
    </nav>

    <!-- Page Content -->
    <div class="container">

      <!-- Page Features -->
        <h1 class="titre">Utilisateurs</h1>
        
        <table class="table table-hover">
            <thead>
              <tr>
                <th>Photo de profil</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Description</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
            if(isset($namesOfResearch)){
                    foreach ($namesOfResearch as $profil) {
                        echo '<tr>
                                    <td><img class="thumbnail img-responsive" src="img/profil/'.$profil["nomCompte"].'.jpg" width="125px" height="125px"></td>
                                    <td>'.$profil["nom"].'</td>
                                    <td>'.$profil["prenom"].'</td>
                                    <td>'.$profil["description"].'</td>
                                    <td>';
                                        if(DemandeAlreadyDone($_SESSION['idUser'],$profil["idUtilisateur"])){
                                            
                                            echo '<a href="profil.php?pseudo='.$profil["nomCompte"].'"> <i class="fa fa-user fa-3x" aria-hidden="true"></i></a>';
                                        }
                                        else{
                                         echo '<a href="profil.php?pseudo='.$profil["nomCompte"].'"> <i class="fa fa-user fa-3x" aria-hidden="true"></i></a>
                                    <a href="users.php?addId='.$profil["idUtilisateur"].'"><i class="fa fa-heart fa-3x" aria-hidden="true"></i></a>';   
                                        }
                                    echo '</td>
                                </tr>';
                    }
            }
            ?>
            </tbody>
        </table>
        <?php 
        if(isset($_REQUEST["searcher"])){
            createPagination($nbPage, $_REQUEST['searcher']);
        }
        else{
            createPagination($nbPage, $_GET['idUserSearch']);
        }
        ?>
    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="footer">
      <div class="container">
        <p class="text-center">Copyright &copy; Target 2017</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="../bootstrap-4.0.0-dist/js/bootstrap.min.js"></script>
	</div>
  </body>

</html>
