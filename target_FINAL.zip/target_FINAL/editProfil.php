<?php
require './model/function_BD.php';
require './model/functions.php';

session_start();

if($_SESSION['idUser'] != $_GET['idUser']){
    header("location:profil.php?". $_SESSION['pseudo']);
    exit;
}

$modifier = true;
$idUser = isset($_GET['idUser']) ? $_GET['idUser'] : null;
$users = getUsersById($idUser);
$caracteristiques = getCaracteristiquesById($idUser);
foreach($users as $user){
    $_SESSION['idUser'] = $user['idUtilisateur'];
    $prenom = $user['prenom'];
    $nom = $user['nom'];
    $pseudo = $user['nomCompte'];
    $email = $user['eMail'];   
    $motDePasse = $user['mdp'];
    $description = $user['description'];
    $dateNaissance = $user['dateNaissance'];
}
foreach($caracteristiques as $caracteristique){
    $genre = $caracteristique['genre'];
    $taille = $caracteristique['taille'];
    $poids = $caracteristique['poids'];
    $emploi = $caracteristique['emplois'];
}

if (isset($_FILES['icone'])) {
    if ($_FILES['icone']['error'] > 0) $erreur = "Erreur lors du transfert";
    $extensions_valides = array( '.jpg' , '.jpeg' , '.gif' , '.png' );
    $extension_upload = strtolower(  substr(  strrchr($_FILES['icone']['name'], '.')  ,1)  );
    if ( in_array($extension_upload,$extensions_valides) ) echo "Extension correcte";
    $nomPicture = "img/profil/".$pseudo.".jpg";
    $resultat = move_uploaded_file($_FILES['icone']['tmp_name'],$nomPicture);
    if ($resultat){
        header("location:editProfil.php?idUser=$idUser");
        exit;
    }
}

if (filter_has_var(INPUT_POST, "submit")) {
    $prenom = trim(filter_input(INPUT_POST, "prenom", FILTER_SANITIZE_STRING));
    $nom = trim(filter_input(INPUT_POST, "nom", FILTER_SANITIZE_STRING));
    $pseudo = trim(filter_input(INPUT_POST, "pseudoInscri", FILTER_SANITIZE_STRING));
    $email = trim(filter_input(INPUT_POST, "mailInscri", FILTER_SANITIZE_EMAIL));
    $motDePasse = trim(filter_input(INPUT_POST, "passwordInscri", FILTER_SANITIZE_STRING));
    $description = trim(filter_input(INPUT_POST, "description", FILTER_SANITIZE_STRING));
    $age = trim(filter_input(INPUT_POST, "age", FILTER_SANITIZE_STRING));
    
    $genre = trim(filter_input(INPUT_POST, "genre", FILTER_SANITIZE_STRING));
    $langue = trim(filter_input(INPUT_POST, "langue", FILTER_VALIDATE_INT));
    $taille = trim(filter_input(INPUT_POST, "taille", FILTER_VALIDATE_INT));
    $poids = trim(filter_input(INPUT_POST, "poids", FILTER_VALIDATE_INT));
    $emploi = trim(filter_input(INPUT_POST, "jobs", FILTER_SANITIZE_STRING));
    $idLieu = trim(filter_input(INPUT_POST, "ville", FILTER_VALIDATE_INT));
    /*if (strcmp($pwd, $pwdConfirm) !== 0) {
        $erreurs['password'] = "Les mots de passe ne correspondent pas !";
        SetFlashMessage($erreurs['password']);
    }*/
    if(empty($nom)){
        $erreurs['nom'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['nom']);
    }
    else if(empty($prenom)){
        $erreurs['prenom'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['prenom']);
    }
    else if(empty($pseudo)){
        $erreurs['pseudo'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['pseudo']);
    }
    else if(empty($motDePasse)){
        $erreurs['motDePasse'] = "Le champ ne peut pas être vide !";
        SetFlashMessage($erreurs['motDePasse']);
    }
    if (empty($erreurs)) {
        updateCaracteristique($genre, $langue, $taille, $poids, $emploi, $idLieu, $_SESSION['idUser']);
        updateUser($pseudo, $email, $motDePasse, $nom, $prenom, $description, $age, $_SESSION['idUser']);
        SetFlashMessage("Votre compte a été modifié");
        header("location:index.php");
        exit;
    }
}

require_once "views/userform.php";