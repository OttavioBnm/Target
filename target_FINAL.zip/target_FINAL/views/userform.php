<?php
clearstatcache();
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!DOCTYPE html>
<html lang="fr">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php
        if($modifier){
            echo "Modification";
        } 
        else{
            echo "Inscription";
        }
    ?>
    </title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap-4.0.0-dist/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Css de la page !-->
	<link href="css/index.css" rel="stylesheet">

  </head>

  <body>
	<div class="fond">
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-toggleable-md fixed-top navbar-inverse">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand" href="index.php">Target</a>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <?php
          ContextNavBar();
          ?>
      </div>
    </nav>

    <!-- Page Content -->
    <div class="container grandContainer">
        <h1 class="display-3">
        <?php
            if($modifier){
                echo "Modification";
            } 
            else{
                echo "Inscription";
            }
        ?>
        </h1>
        <?php
        if($modifier){
           echo ' <div align="center">
            <form action="editProfil.php?idUser='.$idUser.'" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <img class="thumbnail img-responsive profil" src="img/profil/'.$pseudo.'.jpg" width="300px" height="300px">
                </div>
                <label for="icone">image de profil</label><br/>
                <div class="form-group">
                    <input type="file" name="icone" id="icone" /><br />
                    <input type="submit">
                </div>
            </form>
        </div>';
           clearstatcache();
        }
        
        ?>
        <form action="<?php if($modifier){
                                echo "editProfil.php";
                            } 
                            else{
                                echo "register.php";
                            } ?>" method="post">
                    <div class="form-group">
                            <label for="email">Adresse email</label>
                            <input name="mailInscri" value="<?php echo $email;?>" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Entrez votre adresse email">
                            <small id="emailHelp" class="form-text text-muted">Nous ne partagerons votre email avec personne d'autres</small>
                    </div>
                    <?php
                        if (!empty($erreurs['email'])) {
                    ?>
                        <div class="alert alert-danger alert-dismissable" role="alert">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <h4 class="alert-heading">Erreur</h4>
                            <p><?php echo GetFlashMessage(); ?></p>
                        </div>
                    <?php
                        }
                    ?>
                    <div class="form-group">
                            <label for="motdepasse">Mot de passe</label>
                            <input name="passwordInscri" value="<?php echo $motDePasse;?>" type="password" class="form-control" id="exampleInputPassword1" placeholder="Entrez votre mot de passe">
                    </div>
                    <?php
                        if (!empty($erreurs['password'])) {
                    ?>
                        <div class="alert alert-danger alert-dismissable" role="alert">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <h4 class="alert-heading">Erreur</h4>
                            <p><?php echo GetFlashMessage(); ?></p>
                        </div>
                    <?php
                        }
                    ?>
                    <div class="form-group">
                            <label for="pseudo">Pseudo</label>
                            <input name="pseudoInscri" value="<?php echo $pseudo;?>" type="text" class="form-control" id="exampleInputPassword1" placeholder="Entrez votre pseudo">
                    </div>
                    <?php
                        if (!empty($erreurs['pseudo'])) {
                    ?>
                        <div class="alert alert-danger alert-dismissable" role="alert">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <h4 class="alert-heading">Erreur</h4>
                            <p><?php echo GetFlashMessage(); ?></p>
                        </div>
                    <?php
                        }
                    ?>
                    <div class="form-group">
                            <label for="nom">Nom</label>
                            <input name="nom" type="text" value="<?php echo $nom;?>" class="form-control" id="exampleInputPassword1" placeholder="Entrez votre nom">
                    </div>
                    <?php
                        if (!empty($erreurs['nom'])) {
                    ?>
                        <div class="alert alert-danger alert-dismissable" role="alert">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <h4 class="alert-heading">Erreur</h4>
                            <p><?php echo GetFlashMessage(); ?></p>
                        </div>
                    <?php
                        }
                    ?>
                    <div class="form-group">
                            <label for="prenom">Prénom</label>
                            <input name="prenom" type="text" value="<?php echo $prenom;?>" class="form-control" id="exampleInputPassword1" placeholder="Entrez votre prénom">
                    </div>
                    <?php
                        if (!empty($erreurs['prenom'])) {
                    ?>
                        <div class="alert alert-danger alert-dismissable" role="alert">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <h4 class="alert-heading">Erreur</h4>
                            <p><?php echo GetFlashMessage(); ?></p>
                        </div>
                    <?php
                        }
                    ?>
                    <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" class="form-control" id="exampleTextarea" rows="3" placeholder="Entrez une petite description de vous-même :)"><?php echo $description; ?></textarea>
                    </div>
                    <?php 
                        CreateListBoxAge();
                        CreateListBoxHeight();
                        CreateListBoxWeigth();
                        CreateListBoxGender();
                        CreateListBoxCities();
                        CreateListBoxLanguages();
                        //CreateTextBoxJob();
                        CreateListBoxJob();
                    ?>
                    <button type="submit" name="submit" class="btn btn-primary btn-card"><?php if($modifier){echo "Modification";} else{echo "Inscription";}?></button>
		</form>
	</div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="footer">
      <div class="container">
        <p class="text-center">Copyright &copy; Target 2017</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="../bootstrap-4.0.0-dist/js/jquery-3.2.1.js"></script>
    <script src="../bootstrap-4.0.0-dist/js/bootstrap.min.js"></script>
	</div>
  </body>

</html>
