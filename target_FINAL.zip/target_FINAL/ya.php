<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

DEFINE("DB_HOST","ottaviob.mysql.db.hostpoint.ch");
DEFINE("DB_NAME","ottaviob_target");
DEFINE("DB_USER","ottaviob_admin");
DEFINE("DB_PASS","roottoor+7-7");

function getConnexion(){
    static $dbb=null;
    if($dbb==null){
        try{
        $connectionString="mysql:host=".DB_HOST.";dbname=".DB_NAME."";
        $dbb=new PDO($connectionString,DB_USER,DB_PASS, array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
        $dbb->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
        }
        catch(PDOException $e){
            die('Erreur : '. $e->getMessage() );
        }
    }
    return $dbb;
}

getConnexion();

