<?php
session_start();
//AISSA
clearstatcache();
include 'model/function_BD.php';
include 'model/functions.php';
if (isset($_GET['pseudo'])) {
    $SonProfil = checkIfNotAlreadyInPseudo($_GET['pseudo']);
    
    $elPseudo = getUserIdByPseudo($_GET['pseudo']);
    foreach($elPseudo as $pseudos){
        $idUtilisateur = $pseudos['idUtilisateur'];
    }
    
    $caracteristique = getCaracteristiquesById($idUtilisateur);
    foreach ($SonProfil as $infos) {
        $nomUser = $infos['nom'];
        $prenomUser = $infos['prenom'];
        $pseudo = $infos['nomCompte'];
        $description = $infos['description'];
        $dateDeNaissance = $infos['dateNaissance'];
    }
    foreach($caracteristique as $info){
        $taille = $info['taille'];
        $poids = $info['poids'];
        $genre = $info['genre'];
        $emploi = $info['emplois'];
        $idLieu = $info['idLieu'];
        $idLangue = $info['langue'];
    }
    $lieu = getLocation($idLieu);
    foreach ($lieu as $ville){
        $lieux = $ville['lieu'];
    }
    $langue = getLanguagesById($idLangue);
    foreach($langue as $languages){
        $langues = $languages['langue'];
    }
} else {
    gotInfos();
    if(isset($_SESSION["pseudo"])){
    $idUser = $_SESSION['idUser'];
    $nomUser = $_SESSION['nom'];
    $prenomUser = $_SESSION['prenom'];
    $pseudo = $_SESSION['pseudo'];
    $description = $_SESSION['description'];
    $dateDeNaissance=date("Y")-$_SESSION['dateDeNaissance'];
    $taille =   $_SESSION['taille'];
    $poids =    $_SESSION['poids'];
    $genre =    $_SESSION['genre'];
    $idLieu =   $_SESSION['idLieu'];
    $idLangue = $_SESSION['langue'];
    $emploi =   $_SESSION['emplois'];
    $lieu = getLocation($idLieu);
    foreach ($lieu as $ville){
        $lieux = $ville['lieu'];
    }
    $langue = getLanguagesById($idLangue);
    foreach($langue as $languages){
        $langues = $languages['langue'];
    }
    if(isset($_GET["acceptLike"])){
                $idAccepted=$_GET["acceptLike"];
                addMatchs($idAccepted,$idUser);
                DelDemandes($idAccepted,$idUser);
                DelDemandes($idUser,$idAccepted);
                header('Location:profil.php');
            }
            if(isset($_GET["refuseLike"])){
                $idAccepted=$_GET["refuseLike"];
                DelDemandes($idAccepted,$idUser);
                DelDemandes($idUser,$idAccepted);
                header('Location:profil.php');
            }
    
    }
}
if (isset($_FILES['icone'])) {
 if ($_FILES['icone']['error'] > 0) $erreur = "Erreur lors du transfert";
$extensions_valides = array( '.jpg' , '.jpeg' , '.gif' , '.png' );
$extension_upload = strtolower(  substr(  strrchr($_FILES['icone']['name'], '.')  ,1)  );
if ( in_array($extension_upload,$extensions_valides) ) echo "Extension correcte";
$nom = "img/profil/".$pseudo.".jpg";
$resultat = move_uploaded_file($_FILES['icone']['tmp_name'],$nom);
if ($resultat) echo "Transfert réussi";   
}
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="../bootstrap-4.0.0-dist/css/bootstrap.min.css">
        <link href="css/index.css" rel="stylesheet">
        <!-- CSS des icônes !-->
        <link href="../font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet">
    </head>
    <body>
        <div class="container-fluid">
            <div class="row">
                <nav class="navbar navbar-default navbar-toggleable-md fixed-top navbar-inverse">
                    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">Target</a>

                    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
                            <?php 
                           ContextNavBar();
                            ?>
                    </div>
                </nav>

                <div class="row col-lg-12">
                    <div class="col-lg-4 col-md-6 hidden-sm hidden-xs">
                        <div class="panel panel-default">
                            <div class="panel-body">    
                                <div class="media">
                                    <div class="media-body">
                                        <div class="card card-profile">
                                            <div align="center">
                                                <?php
                                              if(isset($idUser)){
                                                
                                              echo '<img class="thumbnail img-responsive profil" src="img/profil/'.$pseudo.'.jpg" width="300px" height="300px">';
                                                }
                                              else{	  
                                              echo '<img class="thumbnail img-responsive profil" src="img/profil/'.$pseudo.'.jpg" width="300px" height="300px">';
                                              }?>
                                            </div>
                                        </div>
                                        <hr id="propriete">
                                        <h3><i class="fa fa-id-card-o" aria-hidden="true"></i><strong><?php echo " " . $pseudo; ?></strong></h3>
                                        <hr>
                                        <h3><i class="fa fa-bookmark" aria-hidden="true"></i><strong> Description</strong></h3>
                                        <p><?php echo $description; ?></p>
                                        <hr>
                                        <h3><i class="fa fa-home" aria-hidden="true"></i><strong> Lieu</strong></h3>
                                        <p><?php echo $lieux; ?></p>
                                        <hr>
                                        <h3><i class="fa fa-venus-mars" aria-hidden="true"></i><strong> Genre</strong></h3>
                                        <p><?php echo $genre; ?></p>
                                        <hr>
                                        <h3><i class="fa fa-calendar" aria-hidden="true"></i><strong> Année de naissance</strong></h3>
                                        <p><?php echo $dateDeNaissance?></p>
                                        <hr>
                                        <h3><i class="fa fa-globe" aria-hidden="true"></i><strong> Langues</strong></h3>
                                        <p><?php echo $langues ?></p>
                                        <hr>
                                        <h3><i class="fa fa-arrows-v" aria-hidden="true"></i><strong> Taille</strong></h3>
                                        <p><?php echo $taille . " cm"; ?></p>
                                        <hr>
                                        <h3><i class="fa fa-balance-scale" aria-hidden="true"></i><strong> Poids</strong></h3>
                                        <p><?php echo $poids . " kg"; ?></p>
                                        <hr>
                                        <h3><i class="fa fa-handshake-o" aria-hidden="true"></i><strong> Emploi</strong></h3>
                                        <p><?php echo $emploi; ?></p>
                                        <?php
                                        if(isset($idUser)){  
                                        ?>
                                            <hr>
                                            <h3><a href="editProfil.php?idUser=<?php echo $idUser;?>"><i class="fa fa-cog" aria-hidden="true"></i><strong> Modifier le profil</strong></a></h3>
                                            <hr>
                                        <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-6 hidden-sm hidden-xs">
                        <div class="post-content post">
                            <div class="panel panel-default">
                                <div class="panel-body matchs">
                                    <?php
                                        if(isset($idUser)){
                                            echo'<h1>Matchs</h1>
                                            <hr>
                                            <table class="table table-striped">';
                                            $matchs= getmatchsById($idUser);
                                            foreach ($matchs as $match) {
                                            $userAsking= getUsersById($match["matchUserOne"]);
                                            echo '<tr>
                                                     <td>
                                                        <div class="pull-left">
                                                            <a href="#">
                                                                <img class="media-object img-circle" src="https://diaspote.org/uploads/images/thumb_large_283df6397c4db3fe0344.png" width="100px" height="100px" style="margin-right:8px; margin-top:-5px;">
                                                            </a>
                                                        </div>
                                                        <h3><a href="profil.php?pseudo='.$userAsking[0]["nomCompte"].'" style="text-decoration:none;"><strong>'.$userAsking[0]["nom"].' '.$userAsking[0]["prenom"].'</strong></a></h3>
                                                     </td>
                                                      <td>
                                                        <p>'.$userAsking[0]["description"].'</p>
                                                    </td>
                                            </tr>';
                                            }
                                            echo '</table>';
                                        }
                                        ?>
                                    
                                        <?php
                                        if(isset($idUser)){
                                        echo '<h1>Demandes</h1>
                                    <hr>
                                    <table class="table table-striped">';
                                        $asking=getDemandesByIdReceiver($idUser);
                                        foreach ($asking as $asker) {
                                        $userAsking= getUsersById($asker["idUserAsking"]);
                                        echo '<tr>
                                                 <td>
                                                    <div class="pull-left">
                                                        <a href="#">
                                                            <img class="media-object img-circle" src="https://diaspote.org/uploads/images/thumb_large_283df6397c4db3fe0344.png" width="100px" height="100px" style="margin-right:8px; margin-top:-5px;">
                                                        </a>
                                                    </div>
                                                    <h3><a href="profil.php?pseudo='.$userAsking[0]["nomCompte"].'" style="text-decoration:none;"><strong>'.$userAsking[0]["nom"].' '.$userAsking[0]["prenom"].'</strong></a></h3>
                                                 </td>
                                                  <td>
                                                    <p>'.$userAsking[0]["description"].'</p>
                                                  </td>
                                                  <td>
                                                    <a href="profil.php?refuseLike='.$userAsking[0]["idUtilisateur"].'"><i class="fa fa-ban fa-2x" aria-hidden="true"></i></a>
                                                    <a href="profil.php?acceptLike='.$userAsking[0]["idUtilisateur"].'"><i class="fa fa-check fa-2x" aria-hidden="true"></i></a>
                                                  </td>
                                        </tr>';
                                        }
                                        echo'</table>';
                                        }
                                        ?>
                                        <?php
                                        if(isset($idUser)){
                                        echo '<h1>Mes demandes</h1>
                                                <hr>
                                                <table class="table table-striped">';
                                        $asking= getDemandesByIdAsking($idUser);
                                        foreach ($asking as $asker) {
                                        $userAsking= getUsersById($asker["idUserReciver"]);
                                        
                                        echo '<tr>
                                                 <td>
                                                    <div class="pull-left">
                                                        <a href="#">
                                                            <img class="media-object img-circle" src="https://diaspote.org/uploads/images/thumb_large_283df6397c4db3fe0344.png" width="100px" height="100px" style="margin-right:8px; margin-top:-5px;">
                                                        </a>
                                                    </div>
                                                    <h3><a href="#" style="text-decoration:none;"><strong>'.$userAsking[0]["nom"].' '.$userAsking[0]["prenom"].'</strong></a></h3>
                                                 </td>
                                                  <td>
                                                    <p>'.$userAsking[0]["description"].'</p>
                                                  </td>
                                                  <td>
                                                    <a href="profil.php?refuseLike='.$userAsking[0]["idUtilisateur"].'"><i class="fa fa-ban fa-2x" aria-hidden="true"></i></a>
                                                  </td>
                                        </tr>';
                                        }
                                        echo '</table>';
                                        }
                                        else if(isset ($_SESSION['idUser'])){
                                            if(DemandeAlreadyDone($_SESSION['idUser'],$idUtilisateur)){
                                                echo '<div class="alert alert-info">
                                                        Vous avez déjà fait une demande à cette personne !
                                                      </div>';
                                            }
                                            else{
                                                echo '<a href="users.php?addId='.$idUtilisateur.'"><i class="fa fa-heart fa-5x" aria-hidden="true"></i></a>';
                                            }
                                        }
                                        ?>
                                    <!--<div class="post-content"></div> !-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>