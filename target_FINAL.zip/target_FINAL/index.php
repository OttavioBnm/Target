<?php
session_start();
include 'model/function_BD.php';
include 'model/functions.php';
gotInfos();
clearstatcache();
$UsersDataBase = getUsers();
?>
<!DOCTYPE html>
<html lang="fr">

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Accueil</title>

    <!-- Bootstrap core CSS -->
    <link href="../bootstrap-4.0.0-dist/css/bootstrap.css" rel="stylesheet">

    <!-- Font !-->
    
    
    <!-- Css de la page !-->
    <link href="css/index.css" rel="stylesheet">
    

  </head>

  <body>
    <div class="fond">
    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-toggleable-md fixed-top navbar-inverse">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand" href="index.php">Target</a>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <?php
          ContextNavBar();
          ?>
      </div>
    </nav>

    <!-- Page Content -->
    <div class="container hidden-lg hidden-md">
      <!-- Jumbotron Header -->
      <?php
      if(isset($_SESSION["pseudo"])){
      ?>
      <header class="jumbotron">
        <h1 class="display-3">Bienvenue !</h1>
        <p class="lead">Target est une application de rencontre  ...</p>
        <?php
                  if (isset($_SESSION["pseudo"])) {
                      echo '';
                  }
                  else{
                      echo '<a href="register.php" class="btn btn-primary btn-lg btn-card">S\'inscire</a>';
                  }
        ?>
      </header>
      <?php
      }
      else{
        echo "<div class=\"jumbotron\"><h1 class=\"display-4\">Profil aléatoire</h1></div>";
          
        if (!empty($_SESSION['message'])) {
            ?>
            <div class="alert alert-success alert-dismissable notification" role="alert">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <h4 class="alert-heading">Notification</h4>
                <p><?php echo GetFlashMessage(); ?></p>
            </div>
        <?php
            }
      }
      ?>
      <!-- Page Features -->
      <div class="row text-center hidden-md">
     
        <?php
        foreach ($UsersDataBase as $ficheUser){
        if(isset($_SESSION['idUser'])){
                if($ficheUser["idUtilisateur"]!=$_SESSION['idUser']){
                    echo '<div class="card randomCard col-lg-3 col-md-6">
                            <img class="thumbnail img-responsive ya" alt="" src="img/profil/'.$ficheUser["idUtilisateur"].'.jpg" style="width:80px; height:80px;">
                            <div class="card-block">
                                <h4 class="card-title">'.$ficheUser["nom"].'  '.$ficheUser["prenom"].'</h4>
                                    <p class="card-text">'.$ficheUser["description"].'</p>
                                    <hr>';
                                    echo'<a href="profil.php?pseudo=' . $ficheUser["nomCompte"]. " \"".'class="btn btn-primary btn-card">Voir profil</a>';
                                    if(!DemandeAlreadyDone($_SESSION['idUser'],$ficheUser["idUtilisateur"]) && !MatchAlreadyDone($_SESSION['idUser'],$ficheUser["idUtilisateur"])){
                                        echo '<a href="users.php?addId='.$ficheUser["idUtilisateur"].'" class="btn btn-primary btn-card">Demande de match</a>';
                                    }
                    echo '</div>
                          </div>';
                }
            }else{
                echo '<div class="card randomCard col-lg-3 col-md-6">
                        <img class="thumbnail img-responsive ya" alt="" src="img/profil/'.$ficheUser["nomCompte"].'.jpg" style="width:80px; height:80px;">
                        <div class="card-block">
                            <h4 class="card-title">'.$ficheUser["nom"].'  '.$ficheUser["prenom"].'</h4>
                                <p class="card-text">'.$ficheUser["description"].'</p>
                                <hr>';
                                echo'<a href="profil.php?pseudo=' . $ficheUser["nomCompte"]. " \"".'class="btn btn-primary btn-card">Voir profil</a>';
                  echo '</div>
                      </div>';
            }
        
    }
        ?>
		
      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="footer">
      <div class="container">
        <p class="text-center">Target &copy Tous droits réservés</p>
      </div>
      <!-- /.container -->
    </footer>

     <!-- Bootstrap core JavaScript -->
    <script src="../bootstrap-4.0.0-dist/js/jquery-3.2.1.js"></script>
    <script src="../bootstrap-4.0.0-dist/js/bootstrap.min.js"></script>
    
    </div>
  </body>

</html>
